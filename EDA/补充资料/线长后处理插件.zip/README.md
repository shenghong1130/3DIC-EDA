# 独立 GUIDE 后处理插件

版本 0.1.0。插件接收任意布线程序生成的 GUIDE，读取配套 DEF/LEF 中的网格和层信息，输出一份新的 GUIDE。无需布线程序、评估器、原生动态库、第三方 Python 包或联网服务。运行环境为 Python 3.10；交付验证使用 Python 3.10.18。

本插件实现一种**保持几何并集的表示后处理**，适用于先按 GCell 去重、再按保留矩形计算普通 via 的旧计数模式。它利用该模式对矩形表示的依赖，降低模型中的普通 via 费用；不缩短物理线路、不移除真实 via。在按实际交叠并集计数的 fair 模式中，不应获得这种收益。运行成功不是官方评分通过或物理合法性证明。

## 快速使用

解压后先运行人工例子自检：

```bash
python3 -B selfcheck.py
```

再对已有结果执行后处理。输出目录必须已经存在，输出文件必须是新路径：

```bash
python3 -B guide_postprocess.py \
  --guide input.guide \
  --def input.def \
  --lef technology.lef \
  --output processed.guide
```

默认处理每网最多 128 个层格的可改网络，选择全部能降低本模型费用的候选。超过这个范围、未对齐网格或涉及短边界格的网络保留原始矩形记录。不会覆盖输入或任何已有输出；失败不会发布不完整 GUIDE。矩形记录的空白格式会被统一。

已知对应评估器的固定输入参考成本 `Lref` 时，可让插件在达到模型线长分 100 后停止，以减少文件膨胀。数值单位必须为 **DBU**，不是 μm，也不是归一化线长。例如人工样例：

```bash
python3 -B guide_postprocess.py \
  --guide examples/synthetic.guide \
  --def examples/synthetic.input.def \
  --lef examples/synthetic.lef \
  --reference-cost 420000 \
  --output synthetic.processed.guide
```

`--reference-cost` 由调用者提供，插件不调用 FLUTE 或从输出猜测参考值。该人工例子的模型成本从 450000 降到 210000 DBU，模型线长分从 93.333333 到 100；这些数值仅描述包内人工输入。

标准输出是 JSON 汇总，可以按需保存：

```bash
python3 -B guide_postprocess.py --guide input.guide --def input.def \
  --lef technology.lef --output processed.guide > summary.json
```

汇总只包含聚合计数、模型成本、可选模型分数和验证范围，不包含文件路径、网名、输入内容散列、身份或机器信息。未提供参考值时，分数字段为 `null`。`target_reached: false` 表示当前候选和预算不足，仍会输出已经检查的改善结果；不能将它解释为全局不可达。退出码 0 表示文件成功写出，2 表示输入、文件或处理失败。

## 接入现有流程

调用顺序是：原布线程序生成 GUIDE → 本插件生成另一份 GUIDE → 调用者使用目标评估器重新评估。先保留原结果，再由完整复测决定使用哪份结果。DEF/LEF 不会被修改，热图不需要作为插件输入。

Python 程序也可直接导入包内单文件：

```python
from guide_postprocess import load_technology, process

technology = load_technology("input.def", ["technology.lef"])
summary = process(
    "input.guide", "processed.guide", technology,
    max_cells_per_net=128,
    max_added_rectangles=2000000,
)
```

无需安装模块，把解压目录加入调用程序的模块搜索路径即可。多份 LEF 使用 `--lef technology.lef cells.lef`，API 传入相同列表。

## 参数和支持范围

| 参数 | 含义 |
|---|---|
| `--guide` | 已有 GUIDE，只读；正面积整数 DBU 矩形 |
| `--def` | 同一设计的 DEF，只读取矩形 DIEAREA 和 GCELLGRID |
| `--lef` | 一份或多份 LEF，读取 routing layer 方向 |
| `--output` | 新输出文件；父目录须存在 |
| `--reference-cost` | 可选的固定输入 Lref，正整数 DBU；达到 100 后停止 |
| `--max-cells-per-net` | 每网可改层格数上限，默认 128，范围 1–4096 |
| `--max-added-rectangles` | 可选的新增矩形数量预算；0 表示不允许增加 |
| `--version` | 显示插件版本 |

当前模型要求二十个连续命名的 `metal1` 到 `metal20` 层，前缀大小写必须一致，并原样保留。跨 die 接口固定为第 10/11 层。平面计费按层方向使用名义格长，普通 via/TSV 的单位代价分别为最大名义格长的 3/6 倍。每轴支持一条从 DIEAREA 下界开始并覆盖上界的规则 GCELLGRID；可存在末端短格。其他技术栈、多段网格声明、未知层、重复网名、空网、零面积或越界矩形明确报错，不自动猜测或裁剪。

算法只改全部矩形均沿完整名义网格边界、非优选方向恰好一格宽的网络。每个普通层格拆成三个正面积整数片，首片在相邻层采用相反角落，其余片补足原区域。第 10/11 层的原始矩形及其相对顺序完整保留。只接受模型费用严格降低的候选，按收益与新增矩形数量之比选择；这是有限候选启发式，不保证最少输出矩形或全局最优。

## 验证范围与限制

每个改动网都检查精确的逐层几何并集、第 10/11 层记录序列，以及模型费用差。输入 GUIDE 在分析和写出期间保持一致才发布结果。这保持原 GCell 覆盖和该接口产生的 TSV 候选；在相同输入和既定推断资源模型下，拥塞需求与热输入保持不变。

插件没有独立的 PIN、障碍、详细金属/via、TSV 工艺和完整连接签核，也不修复原输入已有问题。必须使用实际目标评估器检查输出；不承诺部署平台、增加最小片宽限制的检查器或未来版本接受这些表示。矩形与文件大小会增加，效率分和处理耗时可能改变，不能承诺所有评分项都不变。也不能保证任意 GUIDE 达到 100；若固定平面和 TSV 成本已超过 Lref，单靠此类表示改变无法满分。

`selfcheck.py` 验证包成员散列、人工输入的已知结果、精确并集和覆盖保护；它不是官方评分器。文件完整性清单为 [SHA256.json](SHA256.json)。本包只包含插件、人工例子、说明和自检；不包含真实设计、真实成绩、布线算法、开发日志、内部来源记录或个人信息。
