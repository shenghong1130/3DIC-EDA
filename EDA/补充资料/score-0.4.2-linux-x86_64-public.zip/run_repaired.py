#!/usr/bin/env python3
"""Entry for Python 3.10, including the isolated bundled interpreter."""
import sys
from pathlib import Path
sys.dont_write_bytecode = True
sys.path.insert(0,str(Path(__file__).resolve().parent))
from evaluation.repaired.cli import main
raise SystemExit(main())
