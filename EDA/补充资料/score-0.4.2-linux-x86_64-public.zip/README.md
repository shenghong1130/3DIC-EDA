# score 0.4.2

3D IC 全局布线本地兼容评估器，Linux x86_64 独立运行包。0.4.2 按更新 Q&A 修复合法性检查和非零 LEF ORIGIN 支持，并把不参与运行的第三方源码拆到配套包。本包不是官方发行版，当前平台实现未公开。

```bash
chmod +x score
./score --version
./score examples/minimal.guide --lefs examples/without_obs.lef \
  --input-def examples/minimal.input.def \
  --thermal-json examples/minimal.thermal.json --output-dir result
```

无需安装 Python 或下载依赖。默认 `--mode platform`，也可选择 `announcement` 或 `fair`；三个模式使用相同的合法性检查。旧参数和输出文件名保持兼容。

- 芯片外的 GUIDE 部分裁剪到 DIEAREA，DIE 边界作为末端格线；芯片内部四条边仍必须严格对齐 GCell，不自动吸附。
- 非偏好方向最多跨一个实际 GCell，支持非均匀及边缘网格。
- 支持非零 LEF ORIGIN，PIN、OBS、参考点和资源统计使用一致的坐标变换；不改写用户原始文件。
- 原始 GUIDE net 名称必须存在于 DEF，即使其矩形随后会被过滤。
- 两个 TSV 候选时，排除覆盖本 net PIN 的附带候选并保留唯一实际 TSV；最终连接必须能通过保留的 TSV 实现。

`valid_score=true` 且 `evaluation_outcome=SCORED` 才是有效评分。`VIOLATION` 返回零分、非零退出码且不保留本次评分 CSV；`UNSCORABLE` 和 `INCOMPLETE` 不能当作成绩。旧结果移至 `previous_results/`。

- [修复与迁移说明](docs/QA-0.4.2.zh-CN.md)
- [离线阅读版](docs/QA-0.4.2.zh-CN.html)
- [验证汇总](docs/VALIDATION-0.4.2.json)
- [第三方组件说明](docs/第三方组件说明.zh-CN.md)

配套文件为 `score-0.4.2-third-party-sources-public.zip`，保存原有 GCC/glibc 对应源码和发行补丁。运行无需解压或下载该文件；转发或发布主包时，请同时提供配套源码包。许可证、依赖来源及源码成员散列仍在主包中。主包和源码包分别提供 `SHA256SUMS`。

计分公式及三个模式的区别沿用前版；有效网格和几何纠正可能影响边缘用例的资源与得分。平台模式的多层 PIN 固定占用投影仍是观测假说，Q112 尚无回答；公平模式也不等于官网结果。未执行完整工艺 DRC，未认证求解效率或官方最终排名。
