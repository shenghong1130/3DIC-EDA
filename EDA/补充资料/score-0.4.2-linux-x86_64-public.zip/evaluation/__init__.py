"""Evaluation tools; original supplied evaluator remains unmodified."""
