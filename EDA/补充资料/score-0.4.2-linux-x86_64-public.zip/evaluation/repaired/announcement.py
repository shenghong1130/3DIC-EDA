"""Only approved announcement changes; unresolved policies remain explicit."""
from bisect import bisect_left,bisect_right
from fractions import Fraction
import math
from .core import install
from .legality import (RULES as LEGALITY_RULES, clipped_guides, check_submitted_names,
                       extract_tsv_points, install_grid_boundaries)


def area_cells(box,grid):
    """Positive-area cell coverage; no rounding of exact source coordinates."""
    xl,yl,xh,yh=box
    if xh<=xl or yh<=yl:return set()
    c0=max(0,bisect_right(grid.x_lines,xl)-1)
    c1=min(grid.cols,bisect_left(grid.x_lines,xh))
    r0=max(0,bisect_right(grid.y_lines,yl)-1)
    r1=min(grid.rows,bisect_left(grid.y_lines,yh))
    return {(c,r) for r in range(r0,r1) for c in range(c0,c1)}


def transform_box(box,width,height,x,y,orientation):
    transforms=(lambda a,b:(a,b),lambda a,b:(height-b,a),lambda a,b:(width-a,height-b),
                lambda a,b:(b,width-a),lambda a,b:(width-a,b),lambda a,b:(b,a),
                lambda a,b:(a,height-b),lambda a,b:(height-b,width-a))
    if not 0<=orientation<8:raise ValueError('Unsupported component orientation')
    p,q=transforms[orientation](*box[:2]),transforms[orientation](*box[2:])
    return x+min(p[0],q[0]),y+min(p[1],q[1]),x+max(p[0],q[0]),y+max(p[1],q[1])


def build_pin_exemptions(run,source,common,audit):
    """Ownership comes from DEF connections, never from submitted GUIDE order.

    This index does not replace legacy reference points or die classification.
    """
    dbu=Fraction(str(run.def_definition.GetDatabaseUnits()))
    def exact_scaled(value):
        value=Fraction(value)*dbu
        return value.numerator if value.denominator==1 else value
    components={c.instance_name:c for c in run.def_definition.getComponents()}
    templates={}
    cells={};pin_shapes=0
    for net in run.def_definition.getNets():
        owned=set()
        for connection in net.connections:
            if connection.instance=='PIN':
                positions=run._repair_io_positions.get(connection.pin,())
                geometry=[(layer,(b.xl,b.yl,b.xh,b.yh)) for b,layer,_ in positions]
            else:
                comp=components[connection.instance]
                macro=source[comp.macro_name]
                key=comp.macro_name,connection.pin
                if key not in templates:
                    if connection.pin not in macro['pins']:raise ValueError('Missing source PIN ownership')
                    # Use integer arithmetic whenever the exact rational is an
                    # integer. This is lossless, unlike float/rounded geometry.
                    w,h=(exact_scaled(v) for v in macro['size'])
                    rects=[(layer,tuple(exact_scaled(v) for v in box)) for layer,box in macro['pins'][connection.pin]]
                    templates[key]=w,h,rects
                w,h,rects=templates[key]
                o=int(getattr(comp.orient,'value',comp.orient))
                geometry=[(layer,transform_box(box,w,h,comp.x,comp.y,o)) for layer,box in rects]
            if not geometry:raise ValueError('PIN has no supported source geometry')
            for layer,box in geometry:
                if layer not in run.layer_directions:continue
                if box[0]==box[2] or box[1]==box[3]:
                    # No new admission policy: legacy connectivity remains in
                    # force, but the undefined area-coverage credit is explicit.
                    audit['degenerate_pin_shapes_without_area_credit']=audit.get('degenerate_pin_shapes_without_area_credit',0)+1
                owned.update((c,r,layer) for c,r in area_cells(box,run.gcell_grid))
                pin_shapes+=1
        cells[net.name]=owned
    run._repair_pin_cells=cells
    audit['pin_exemption']={'source':'all supported macro and IO PIN PORTs; DEF ownership',
                           'pin_shapes_checked':pin_shapes,'net_cell_layer_entries':sum(map(len,cells.values())),
                           'geometry':'positive area per cell, without track-matching conditions'}


def check_gcell_alignment(raw_guides,grid,checker,audit):
    """Q102/Q108/Q110: exact effective edges after clipping, before dedup."""
    xs,ys=set(grid.x_lines),set(grid.y_lines)
    checked=violations=0;examples=[];counters={'raw':0}
    for name, (xl,yl,xh,yh,layer) in clipped_guides(raw_guides,grid,counters):
        checked+=1
        bad=[label for label,value,lines in
             (('xl',xl,xs),('yl',yl,ys),('xh',xh,xs),('yh',yh,ys)) if value not in lines]
        if bad:
            violations+=1
            if len(examples)<10:
                examples.append({'net':name,'layer':layer,'bounds':[xl,yl,xh,yh],'unaligned_edges':bad})
    audit['gcell_alignment']={'rule':'Q102/Q108/Q110','all_raw_rectangles_checked':counters['raw'],
        'retained_rectangles_checked':checked,'violations':violations,
        'first_violations':examples,'geometry':'DIE-clipped source rectangles before deduplication',
        'boundary_source':'effective GCell x_lines and y_lines including DIE boundaries; exact membership'}
    if violations:
        raise checker.EvaluationError('GUIDE boundaries are not aligned to GCell (Q102): '+str(examples[0]),
            category=checker.LEGALITY,rule='Q102: all GUIDE boundaries must lie on GCell lines',
            hint='Correct interior GUIDE boundaries; only DIEAREA clipping is applied, without grid snapping.')


def install_announcement(modules,audit,source,mode,*,pin_builder=build_pin_exemptions):
    if mode not in ('announcement','fair'):raise ValueError('Unknown rule profile')
    common,checker,hpwl,wire_length,score=modules
    install(modules,audit,source,mode)
    install_grid_boundaries(score,audit)
    score.extract_tsv_points=lambda run,grid:extract_tsv_points(run,grid,common,checker,score.TSVPoint,audit)
    audit['legality_rules']=LEGALITY_RULES
    raw_guides={}
    parser=common.parse_guide
    def parse(path):
        result=parser(path)
        # Vendor clipping mutates GuideRect objects. Store immutable coordinates,
        # not references to those objects, without expensive per-object copying.
        raw_guides.update({name:tuple((r.xl,r.yl,r.xh,r.yh,r.layer) for r in rects) for name,rects in result.items()})
        return result
    common.parse_guide=parse
    check=checker.check
    def full_check(run):
        check_submitted_names(raw_guides,run,checker,audit)
        check_gcell_alignment(raw_guides,run.gcell_grid,checker,audit)
        checked=0;violations=[]
        xs={x:i for i,x in enumerate(run.gcell_grid.x_lines)}
        ys={y:i for i,y in enumerate(run.gcell_grid.y_lines)}
        for name,(xl,yl,xh,yh,layer) in clipped_guides(raw_guides,run.gcell_grid):
            if layer not in run.layer_directions:continue # legacy Routing check diagnoses this
            direction=run.layer_directions[layer]
            extent=yh-yl if direction=='HORIZONTAL' else xh-xl
            if direction not in ('HORIZONTAL','VERTICAL'):
                raise checker.EvaluationError('Unsupported layer direction',category=common.INPUT,
                    rule='Defined routing direction',hint='Check trusted LEF/DEF inputs.')
            checked+=1
            cells=ys[yh]-ys[yl] if direction=='HORIZONTAL' else xs[xh]-xs[xl]
            if cells>1:
                violations.append({'net':name,'layer':layer,'bounds':[xl,yl,xh,yh],
                                   'perpendicular_extent':extent,'actual_cells_spanned':cells,'limit_cells':1})
        audit['perpendicular_width']={'all_raw_rectangles_checked':checked,'violations':len(violations),
                                    'first_violations':violations[:10],'limit':'one actual effective GCell after DIE clipping'}
        if violations:
            first=violations[0]
            raise checker.EvaluationError('GUIDE exceeds one GCell perpendicular to layer direction: '+str(first),
                category=checker.LEGALITY,rule='Perpendicular GUIDE size <= one GCell',hint='Correct the submitted rectangle geometry.')
        check(run)
        pin_builder(run,source,common,audit)
        audit['preliminary_legality_completed']=True
    checker.check=full_check
    # score.py imported check by value; replacing only checker.check would
    # leave the actual CLI entry pointing to the old function.
    score.check=full_check
    original_score=score.compute_score
    def compute(norm_wire_length,norm_overflow,correlation,thermal_gain):
        length=float(norm_wire_length)
        if not math.isfinite(length) or length<0:raise ValueError('Invalid normalized wire length')
        result=original_score(norm_wire_length,norm_overflow,correlation,thermal_gain)
        # Keeping the old positive epsilon at L=0 gives the same right limit;
        # this introduces no new zero-TSV or zero-reference admission rule.
        quality=min(1.0,1.0/max(length,1e-9))
        result['wirelength_quality']=quality
        result['wirelength_score']=100.0*quality
        return result
    score.compute_score=compute
    audit['rules']='announcement-candidate-v1' if mode=='announcement' else 'announcement-with-approved-ordinary-via-components-v1'
