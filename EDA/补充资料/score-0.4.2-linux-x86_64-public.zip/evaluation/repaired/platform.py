"""Observed-platform compatibility profile, separate from physical geometry.

This is an inferred numerical model, not published official source. Macro PIN
layer projection applies only to fixed demand; connectivity and reference
geometry always retain every original layer. See docs/PLATFORM-0.4.0.zh-CN.md.
"""
from bisect import bisect_left, bisect_right
from collections import Counter
from types import SimpleNamespace

from . import core
from .announcement import build_pin_exemptions, install_announcement

RULES = 'platform-compatible-v1'


def resource_geometry(source):
    """Two independent PIN views without mutating the trusted source geometry.

    Fixed demand projects all rectangles of a macro PIN onto the layer of its
    first rectangle. Own-net credit keeps only rectangles originally on that
    layer. OBS multiplicity/layers and PIN declaration order are preserved.
    """
    fixed, credit = {}, {}
    for name, macro in source.items():
        remaining = Counter((layer, tuple(box)) for layer, box in macro['rectangles'])
        projected, retained = [], {}
        for pin, shapes in macro['pins'].items():
            retained[pin] = []
            if not shapes:
                continue
            first = shapes[0][0]
            for layer, box in shapes:
                key = layer, tuple(box)
                remaining[key] -= 1
                if remaining[key] < 0:
                    raise ValueError('PIN geometry missing from source rectangle inventory')
                projected.append((first, tuple(box)))
                if layer == first:
                    retained[pin].append((layer, tuple(box)))
        obstacles = [key for key, count in remaining.items() for _ in range(count)]
        fixed[name] = dict(macro, rectangles=obstacles + projected)
        credit[name] = dict(macro, pins=retained)
    return fixed, credit


def fixed_track_demand(run, common, capacity, source):
    """Half-open rectangle projection, exact track union, including zero entries.

    Cell ownership and capacity keep the shared physical track definition.
    Only cells covered by the rectangle participate; a track on the upper
    rectangle edge is excluded even at the final exterior grid boundary.
    """
    view = SimpleNamespace(def_definition=run.def_definition,
                           layer_directions=run.layer_directions,
                           _repair_lef_geometry=source,
                           _repair_io_positions=getattr(run, '_repair_io_positions', {}))
    grid, used = run.gcell_grid, {}
    for layer, (xl, yl, xh, yh) in core.fixed_rectangles(view, common):
        cols = common.rectangle_cell_indices(xl, xh, grid.x_lines)
        rows = common.rectangle_cell_indices(yl, yh, grid.y_lines)
        horizontal = run.layer_directions[layer] == 'HORIZONTAL'
        tracks = capacity.tracks.get(layer, {}).get('Y' if horizontal else 'X', ())
        lines = grid.y_lines if horizontal else grid.x_lines
        lower, upper = (yl, yh) if horizontal else (xl, xh)
        main, cross = (rows, cols) if horizontal else (cols, rows)
        begin, end = bisect_left(tracks, lower), bisect_left(tracks, upper)
        for cell in main:
            base = bisect_left(tracks, lines[cell])
            stop = (bisect_right if cell == len(lines)-2 else bisect_left)(tracks, lines[cell+1])
            a, b = max(begin, base), min(end, stop)
            bits = ((1 << (b-a))-1) << (a-base) if b > a else 0
            for other in cross:
                key = (other, cell, layer) if horizontal else (cell, other, layer)
                used[key] = used.get(key, 0) | bits
    return {key: bits.bit_count() for key, bits in used.items()}


def install_platform(modules, audit, source):
    fixed, credit = resource_geometry(source)

    def pins(run, original, common, record):
        build_pin_exemptions(run, credit, common, record)
        record['pin_exemption']['source'] = 'macro PIN rectangles originally on first geometry layer; all supported IO PORTs; DEF ownership'
        record['pin_exemption']['policy'] = 'only-shapes-on-first-layer'

    # Pass the original geometry into the legality and reference-length path.
    install_announcement(modules, audit, source, 'announcement', pin_builder=pins)
    common, _, _, _, score = modules
    score.compute_congestion = lambda run, points: core.congestion(
        run, points, common, audit,
        fixed_counter=lambda data, c, cap: fixed_track_demand(data, c, cap, fixed))
    audit['rules'] = RULES
    audit['platform_compatibility'] = {
        'basis': 'inferred from observed outputs; not official source',
        'fixed_macro_pins': 'all rectangles projected onto first geometry layer',
        'fixed_obs_and_io': 'original geometry layers',
        'fixed_track_interval': '[lower, upper)',
        'retain_zero_fixed_entries': True,
        'macro_pin_credit': 'only-shapes-on-first-layer',
        'io_policy': 'all supported original layers; multilayer behavior unconfirmed',
        'physical_geometry_rewritten': False,
    }
