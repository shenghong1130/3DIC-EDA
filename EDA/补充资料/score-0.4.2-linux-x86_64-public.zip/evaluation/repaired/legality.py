"""Shared Q&A legality: clipped GCells, submitted names and one actual TSV."""
from fractions import Fraction

from .core import connected

RULES = 'QA-Q25-Q62-Q97-Q101-Q103-Q108-Q110-v1'


def install_grid_boundaries(score, audit):
    original = score.expand_grid_lines

    def expand(statements, die_lower, die_upper, axis):
        lines, warnings = original(statements, die_lower, die_upper, axis)
        # Explicit DIE boundaries define terminal cells even when GCELLGRID
        # statements overshoot. Do not create extrapolated interior grid lines.
        effective = tuple(sorted({die_lower, die_upper} |
                                 {v for v in lines if die_lower < v < die_upper}))
        if die_lower >= die_upper:
            raise score.EvaluationError('DIEAREA must have positive extent', category=score.INPUT,
                                        rule='Valid DEF DIEAREA', hint='Check the trusted DEF input.')
        audit.setdefault('effective_gcell_grid', {})[axis] = {
            'declared_or_extended_boundaries': len(lines), 'effective_boundaries': len(effective),
            'die_lower': die_lower, 'die_upper': die_upper, 'changed': effective != lines}
        if effective != lines:
            warnings = [*warnings, 'GCELLGRID '+axis+' clipped to explicit DIEAREA terminal boundaries (Q108/Q110)']
        return effective, warnings

    score.expand_grid_lines = expand


def clipped_guides(raw_guides, grid, counters=None):
    """Check every submitted rectangle before deduplication, after DIE clipping.

    A rectangle wholly outside DIEAREA has no retained geometry. Degenerate
    rectangles inside the die still undergo boundary checks, as in 0.4.1.
    """
    die = grid.die
    for name, rectangles in raw_guides.items():
        for xl, yl, xh, yh, layer in rectangles:
            if counters is not None:
                counters['raw'] += 1
            if xh < die.x1 or xl > die.x2 or yh < die.y1 or yl > die.y2:
                continue
            yield name, (max(xl, die.x1), max(yl, die.y1),
                         min(xh, die.x2), min(yh, die.y2), layer)


def check_submitted_names(raw_guides, run, checker, audit):
    names = {net.name for net in run.def_definition.getNets()}
    unknown = set(raw_guides)-names
    audit['submitted_net_names'] = {'submitted': len(raw_guides), 'unknown': len(unknown),
                                   'checked_before_geometry_filtering': True}
    if unknown:
        raise checker.EvaluationError('GUIDE contains unknown net: '+min(unknown),
            category=checker.LEGALITY, rule='Q25: every submitted net must exist in DEF',
            hint='Remove the unknown net, including its zero-area or discarded geometry.')


def extract_tsv_points(run, grid, common, checker, point_type, audit):
    """Select one TSV using actual PIN shapes, then validate that connection.

    The one-candidate rule and output fields retain their existing meaning.
    Two candidates require exactly one PIN-overlapping candidate and exactly
    one free candidate; zero or two free candidates cannot identify a TSV.
    """
    record = {'rule': RULES, 'cross_die_nets_checked': 0, 'pin_candidates_excluded': 0,
              'selected_TSV_connectivity_checked': 0, 'pin_test': 'any own M10/M11 PIN RECT'}
    audit['tsv_legality'] = record
    points = []

    def illegal(net, reason):
        raise checker.EvaluationError('TSV legality for net '+net+': '+reason,
            category=checker.LEGALITY, rule='Q25/Q62/Q103: one actual TSV with connected endpoints',
            hint='Keep one unambiguous TSV and connect both dies through that selected location.')

    for net, rectangles in run.net_guides.items():
        layers = {common.parse_layer_num(rect.layer) for rect in rectangles}
        die = run.net_to_die[net]
        if die in ('bottom', 'top'):
            if (die == 'bottom' and any(layer > 10 for layer in layers) or
                    die == 'top' and any(layer < 11 for layer in layers)):
                illegal(net, 'an intra-die net uses the other die')
            continue
        lower = [r for r in rectangles if r.layer == common.TSV_LOWER_LAYER]
        upper = [r for r in rectangles if r.layer == common.TSV_UPPER_LAYER]
        candidates = set()
        for a in lower:
            for b in upper:
                x1, y1 = max(a.xl, b.xl), max(a.yl, b.yl)
                x2, y2 = min(a.xh, b.xh), min(a.yh, b.yh)
                if x1 < x2 and y1 < y2:
                    candidates.add(((x2-x1)*(y2-y1), x1, y1, x2, y2, a.layer, b.layer))
        if not 1 <= len(candidates) <= 2:
            illegal(net, 'expected one or two positive-area M10/M11 candidates')
        if len(candidates) == 2:
            # A logical PIN may have multiple PORTs/RECTs. Do not use only the
            # first accessed RECT or require all interface PINs to coincide.
            pins = [box for positions in run.net_to_pins[net].values()
                    for box, layer, _ in positions
                    if layer in (common.TSV_LOWER_LAYER, common.TSV_UPPER_LAYER)]
            free = [c for c in candidates if not any(
                max(c[1], b.xl) < min(c[3], b.xh) and max(c[2], b.yl) < min(c[4], b.yh)
                for b in pins)]
            if len(free) != 1:
                illegal(net, 'two candidates do not leave exactly one non-PIN TSV')
            selected = free[0]
            record['pin_candidates_excluded'] += 1
        else:
            selected = next(iter(candidates))
        area, x1, y1, x2, y2, lower_layer, upper_layer = selected
        exact_center = Fraction(x1+x2, 2), Fraction(y1+y2, 2)
        if not connected(rectangles, common, run.layer_directions, tsv_point=exact_center):
            illegal(net, 'GUIDE is disconnected when only the selected TSV is used')
        record['cross_die_nets_checked'] += 1
        record['selected_TSV_connectivity_checked'] += 1
        x, y = map(float, exact_center)
        points.append(point_type(net=net, x_dbu=x, y_dbu=y,
            x_um_local=(x-grid.die.x1)/grid.dbu_per_micron,
            y_um_local=(y-grid.die.y1)/grid.dbu_per_micron,
            gcell_col=common.locate_interval(grid.x_lines,x),
            gcell_row=common.locate_interval(grid.y_lines,y), source='M10_M11_guide_overlap',
            overlap_area_dbu2=float(area), top_layer=lower_layer, bottom_layer=upper_layer))
    audit['legality_completed'] = True
    return points
