"""Score command with explicit platform, announcement and fair profiles."""
from __future__ import annotations
import argparse
from contextlib import redirect_stdout,redirect_stderr
from datetime import datetime,timezone
import fcntl
import json
import math
import os
from pathlib import Path
import resource
import shutil
import sys
import tempfile
import time
import uuid
from . import __version__
from .announcement import install_announcement
from .platform import RULES as PLATFORM_RULES, install_platform
from .input_guard import validate_lef_geometry
from .runtime import ARCHIVE_SHA256,SCORE_SHA256,load,sha256

MANAGED=('evaluation_report.txt','heat_gcell.csv','tsv_gcell.csv',
         'thermal_node_count_per_gcell.csv','tsv_points.csv','overflow_gcells.csv',
         'run_record.json','evaluation_report.json')

def dump(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def validate_finite(value):
    if isinstance(value,float) and not math.isfinite(value):raise ValueError('Non-finite JSON number')
    if isinstance(value,dict):
        for child in value.values():validate_finite(child)
    elif isinstance(value,list):
        for child in value:validate_finite(child)

def positive(value):
    result=float(value)
    if not math.isfinite(result) or result<0:raise argparse.ArgumentTypeError('Expected a finite nonnegative ratio')
    return result

def create_parser():
    p=argparse.ArgumentParser(prog='score',description='Global-routing evaluation with an inferred platform compatibility profile.')
    p.add_argument('guide',type=Path)
    p.add_argument('--lefs',nargs='+',required=True,help='LEFs separated by commas or spaces')
    p.add_argument('--input-def',type=Path,required=True)
    p.add_argument('--thermal-json',type=Path,required=True)
    p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--tsv-cost-ratio',type=positive,default=6.)
    p.add_argument('--via-cost-ratio',type=positive,default=3.)
    p.add_argument('--tsv-congestion-ratio',type=positive,default=1.)
    p.add_argument('--mode',choices=('platform','announcement','fair'),default='platform',
                   help='platform: observed-output compatibility (default); announcement/fair: preserved scoring profiles; all modes share the Q&A legality checks')
    p.add_argument('--runtime',type=Path,default=Path(__file__).resolve().parents[2]/'vendor',help=argparse.SUPPRESS)
    p.add_argument('--version',action='version',version='score '+__version__)
    return p

def archive_outputs(out,token):
    """Never leave a previous PASS current when a native process aborts."""
    old=[n for n in MANAGED if (out/n).exists() or (out/n).is_symlink()]
    if any((out/n).is_symlink() or not (out/n).is_file() for n in old):
        raise ValueError('A managed output name is not an ordinary file')
    if old:
        history=out/'previous_results'/token;history.mkdir(parents=True,exist_ok=False)
        for n in old:os.replace(out/n,history/n)

def publish(stage,out,token):
    """Back up only managed files; publish JSON last as completion marker."""
    archive_outputs(out,token)
    for n in MANAGED:
        if (stage/n).is_file():os.replace(stage/n,out/n)

def main(argv=None):
    parser=create_parser();args=parser.parse_args(argv)
    args.lefs=[Path(x) for value in args.lefs for x in value.split(',') if x]
    if not args.lefs:parser.error('--lefs must contain a path')
    args.runtime=args.runtime.resolve()
    out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    sources=[('def',args.input_def),('guide',args.guide),('thermal',args.thermal_json)]
    sources.extend((f'lef{i}',path) for i,path in enumerate(args.lefs))
    if any(path.resolve() in {out/n for n in MANAGED} for _,path in sources):
        print('Refusing to overwrite an input with a result file.',file=sys.stderr);return 1
    lock=(out/'.score.lock').open('a')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        lock.close();print('Output directory is in use.',file=sys.stderr);return 1
    started=time.perf_counter();previous=Path.cwd();token=uuid.uuid4().hex
    audit={'version':__version__,'mode':args.mode,'started_utc':datetime.now(timezone.utc).isoformat(),
           'input_sha256':{},'complete_evaluation':False,'baseline_archive_sha256':ARCHIVE_SHA256,
           'baseline_score_sha256':SCORE_SHA256,'rules':PLATFORM_RULES if args.mode=='platform' else
           'announcement-candidate-v1' if args.mode=='announcement' else 'announcement-with-approved-ordinary-via-components-v1',
           'cost_parameters':{'tsv':args.tsv_cost_ratio,'via':args.via_cost_ratio,'tsv_congestion':args.tsv_congestion_ratio}}
    audit['standard_parameters']=audit['cost_parameters']=={'tsv':6.,'via':3.,'tsv_congestion':1.}
    code=1;phase='INPUT'
    try:
        archive_outputs(out,token+'-previous')
        dump(out/'evaluation_report.json',{'status':'FAIL','evaluation_outcome':'UNSCORABLE','score':None,
             'valid_score':False,'category':'INCOMPLETE','error':'Evaluation started but no completed result has been published.',
             'repair':{'version':__version__,'rules':audit['rules'],'mode':args.mode,
                       'all_evaluation_stages_completed':False,'S4':None,'official_final_rank_score':None}})
        with tempfile.TemporaryDirectory(prefix='.score-work-',dir=out) as temporary:
            stage=Path(temporary);paths={}
            try:
                for label,path in sources:
                    source=path.resolve(strict=True)
                    target=stage/'inputs'/label/('input'+('.lef' if label.startswith('lef') else '.'+label))
                    target.parent.mkdir(parents=True,exist_ok=True)
                    digest=sha256(source);shutil.copyfile(source,target)
                    if sha256(target)!=digest:raise ValueError('Input changed during snapshot: '+label)
                    paths[label]=target;audit['input_sha256'][label]=digest
                payload=json.loads(paths['thermal'].read_text(encoding='utf-8-sig'));validate_finite(payload);del payload
                normalized_lefs={}
                counts,geometry=validate_lef_geometry([paths[f'lef{i}'] for i in range(len(args.lefs))],
                                                     collect=True,normalized_lefs=normalized_lefs)
                audit['supported_input_geometry']=counts
                normalized_hashes={};normalized_count=0
                for i in range(len(args.lefs)):
                    key=f'lef{i}';replacement=normalized_lefs.get(paths[key])
                    if replacement is not None:
                        target=stage/'canonical_lefs'/(key+'.lef');target.parent.mkdir(exist_ok=True)
                        target.write_text(replacement['text'],encoding='utf-8')
                        paths[key]=target;normalized_hashes[key]=sha256(target)
                        normalized_count+=replacement['rectangles_normalized']
                audit['lef_rect_normalization']={'rectangles_normalized':normalized_count,
                    'canonical_runtime_lef_sha256':normalized_hashes,'original_inputs_modified':False,
                    'coordinate_comparison':'exact rational; corner ordering and ORIGIN translation in private snapshots'}
                audit['lef_origin_normalization']={'macros_normalized':counts.get('nonzero_origins',0),
                    'rule':'Q97; translate local RECTs before orientation and DEF placement',
                    'original_inputs_modified':False}
                del normalized_lefs
                phase='INTERNAL';modules=load(args.runtime)
                common,checker,hpwl,wire,score=modules
                if args.mode=='platform':install_platform(modules,audit,geometry)
                else:install_announcement(modules,audit,geometry,args.mode)
                identities=json.loads(Path(__file__).with_name('case-identities.json').read_text())
                identity=identities.get(audit['input_sha256']['def'])
                if identity:
                    if audit['input_sha256']['thermal']!=identity['thermal_sha256'] or sorted(
                        audit['input_sha256'][f'lef{i}'] for i in range(len(args.lefs)))!=sorted(identity['lef_sha256']):
                        phase='INPUT';raise ValueError('Known DEF does not match trusted LEF/thermal inputs')
                    gain,source=identity['gain'],'content-verified:'+identity['case']
                else:gain,source=20.,'declared-October-default:unregistered-case'
                score.resolve_thermal_gain=lambda table,input_def:(gain,source)
                audit['thermal_gain_identity']={'gain':gain,'source':source}
                cwd=stage/'runtime_work';cwd.mkdir()
                for n in ('POST9.dat','POWV9.dat'):(cwd/n).symlink_to(args.runtime/n)
                os.chdir(cwd)
                vendor_args=[str(paths['guide']),'--lefs',','.join(str(paths[f'lef{i}']) for i in range(len(args.lefs))),
                    '--input-def',str(paths['def']),'--thermal-json',str(paths['thermal']),'--output-dir',str(stage),
                    '--tsv-cost-ratio',str(args.tsv_cost_ratio),'--via-cost-ratio',str(args.via_cost_ratio),
                    '--tsv-congestion-ratio',str(args.tsv_congestion_ratio)]
                with (stage/'vendor_diagnostics.txt').open('w',encoding='utf-8') as capture:
                    with redirect_stdout(capture),redirect_stderr(capture):
                        try:score.run(vendor_args);code=0
                        except SystemExit as error:code=int(error.code or 0)
                report=json.loads((stage/'evaluation_report.json').read_text(encoding='utf-8'))
                validate_finite(report)
                passed=report.get('status')=='PASS' and code==0
                violation=not passed and report.get('category') in (checker.LEGALITY,score.EFFICIENCY)
                report['evaluation_outcome']='SCORED' if passed else 'VIOLATION' if violation else 'UNSCORABLE'
                report['valid_score']=passed
                if not passed:report['score']=0.0 if violation else None
                report['status']='PASS' if passed else 'FAIL'
                report['efficiency_score']=0 if violation and report.get('category')==score.EFFICIENCY else None
                audit['complete_evaluation']=passed
                if passed:
                    report['wirelength']['gcell_union_and_connection_cost_dbu']=report['wirelength'].get('guide_mst_proxy_dbu')
                    report['wirelength']['tsv_cost_ratio']=args.tsv_cost_ratio
                    report['wirelength']['tsv_cost_dbu_each']=args.tsv_cost_ratio*max(audit['congestion']['gcell_width_dbu'],audit['congestion']['gcell_height_dbu'])
                    report['wirelength']['ordinary_via_proxy']='overlap-components-v1' if args.mode=='fair' else 'rectangle'
                    report['wirelength']['tsv_proxy']='unchanged October rectangle counting and selected thermal/congestion point'
                report['repair']={'version':__version__,'rules':audit['rules'],'mode':args.mode,
                    'all_evaluation_stages_completed':passed,'S4':None,'official_final_rank_score':None,
                    'checks':{'gcell_alignment_Q102':('passed' if audit['gcell_alignment']['violations']==0 else 'failed')
                              if 'gcell_alignment' in audit else 'not_completed',
                              'announcement_geometry':'passed' if passed else 'see_failure',
                              'all_nets_pins_and_TSV':'passed' if passed else 'see_failure',
                              'selected_TSV_connectivity':('passed' if audit.get('legality_completed') else 'not_completed'),
                              'wire_congestion_thermal':'completed' if passed else 'not_complete',
                              'physical_DRC':'not_checked_requires_entities_and_technology',
                              'solver_12h_128GB_S4':'not_checked_requires_external_receipt'},
                    'ranking_compatible_only_with_same_profile_and_parameters':True,
                    'standard_parameters':audit['standard_parameters']}
                code=0 if passed else 1
            except Exception as error:
                report={'status':'FAIL','evaluation_outcome':'UNSCORABLE','score':None,'valid_score':False,
                        'category':phase,'error':str(error),'error_type':type(error).__name__,
                        'legality_score':None,'efficiency_score':None,
                        'repair':{'version':__version__,'rules':audit['rules'],'mode':args.mode,
                                  'all_evaluation_stages_completed':False,'S4':None,'official_final_rank_score':None}}
                code=1
            finally:os.chdir(previous)
            usage=resource.getrusage(resource.RUSAGE_SELF)
            audit.update(exit_code=code,wall_seconds=time.perf_counter()-started,cpu_seconds=usage.ru_utime+usage.ru_stime,
                         peak_rss_kib=usage.ru_maxrss,completed_utc=datetime.now(timezone.utc).isoformat())
            report['inputs']={'guide':str(args.guide),'lefs':[str(p) for p in args.lefs],
                              'defs':[str(args.input_def)],'thermal_json':str(args.thermal_json)}
            dump(stage/'evaluation_report.json',report);dump(stage/'run_record.json',audit)
            (stage/'evaluation_report.txt').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            if not report['valid_score']:
                for n in MANAGED:
                    if n.endswith('.csv') and (stage/n).exists():(stage/n).unlink()
            publish(stage,out,token)
    finally:os.chdir(previous);lock.close()
    print(json.dumps({'status':report['status'],'evaluation_outcome':report['evaluation_outcome'],
                     'valid_score':report['valid_score'],'rule_profile':audit['rules'],
                     'report':str(out/'evaluation_report.json')},ensure_ascii=False,allow_nan=False))
    return code
