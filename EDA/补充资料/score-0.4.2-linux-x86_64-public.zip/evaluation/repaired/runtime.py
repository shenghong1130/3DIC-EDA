"""Verify and load the untouched, specifically identified vendor dependencies."""
from pathlib import Path
import ctypes
import hashlib
import importlib
import json
import marshal
import sys
import types

ARCHIVE_SHA256 = "6f5052859013bdcdd69423e74f37a9969cc11336af043afeb55b8ec66ed35983"
SCORE_SHA256 = "4104d0b2869ef7376d716ce9c33b56668e659575ab84615f5c0a5f282e108a8a"


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024*1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(directory):
    if sys.version_info[:2] != (3, 10):
        raise RuntimeError("Pinned vendor bytecode requires Python 3.10")
    root = Path(directory).resolve()
    manifest = json.loads(Path(__file__).with_name("vendor-lock.json").read_text())
    for name, expected in manifest["files"].items():
        if sha256(root/name) != expected:
            raise ValueError("Vendor dependency integrity failure: "+name)
    unpacked = root/"unpacked"
    for name in ("common", "checker", "hpwl", "wire_length", "eval_errors"):
        if name in sys.modules:
            raise RuntimeError("Run each evaluation in a fresh process: module collision "+name)
    for name in ("libfmt.so.10", "libflute.so"):
        ctypes.CDLL(str(unpacked/name), mode=ctypes.RTLD_GLOBAL)
    sys.path.insert(0, str(unpacked))
    common, checker, hpwl, wire_length = [importlib.import_module(n)
                                        for n in ("common", "checker", "hpwl", "wire_length")]
    for module in (common, checker, hpwl, wire_length):
        if Path(module.__file__).resolve().parent != unpacked:
            raise RuntimeError("Unexpected vendor module origin")
    score = types.ModuleType("repaired_vendor_score")
    score.__file__ = str(unpacked/"score.py")
    sys.modules[score.__name__] = score
    exec(marshal.loads((unpacked/"score").read_bytes()), score.__dict__)
    return common, checker, hpwl, wire_length, score
