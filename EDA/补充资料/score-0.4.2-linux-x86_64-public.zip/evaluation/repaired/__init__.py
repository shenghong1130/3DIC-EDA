"""Auditable repairs for the hash-pinned October 2026 evaluator."""

__version__ = "0.4.2"
