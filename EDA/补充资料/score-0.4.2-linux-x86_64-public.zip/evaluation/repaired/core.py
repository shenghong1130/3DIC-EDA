"""Source repairs; unchanged vendor rules are injected explicitly by install().

All geometry is evaluated, without sampling. Integer track identities and
arbitrary-precision bit masks preserve exact fixed-resource unions. This is a
global-routing evaluator, not a detailed-route DRC implementation.
"""
from __future__ import annotations

from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from collections.abc import Mapping
from fractions import Fraction
import math
from pathlib import Path
import re
import time


def track_indices(tracks, lower, upper, cell_lower, cell_upper, final=False):
    start = max(bisect_left(tracks, lower), bisect_left(tracks, cell_lower))
    stop = min(bisect_right(tracks, upper),
               (bisect_right if final else bisect_left)(tracks, cell_upper))
    return range(start, max(start, stop))


class Capacity(Mapping):
    """Exact lazy equivalent of the full layer/row/col/direction table.

    Coordinates are physical track identities, so duplicate declarations do
    not invent tracks. Tracks outside DIEAREA contribute no capacity.
    """
    def __init__(self, patterns, grid):
        self.grid = grid
        self.tracks = {}
        self.counts = {}
        for layer, axes in patterns.items():
            self.tracks[layer] = {}
            for axis, direction, lines in (("X", "VERTICAL", grid.x_lines),
                                           ("Y", "HORIZONTAL", grid.y_lines)):
                coords = sorted({v for p in axes.get(axis, ()) for v in p.coordinates()
                                 if lines[0] <= v <= lines[-1]})
                self.tracks[layer][axis] = coords
                starts = [bisect_left(coords, x) for x in lines]
                starts[-1] = bisect_right(coords, lines[-1])
                self.counts[layer, direction] = tuple(b-a for a, b in zip(starts, starts[1:]))

    def __getitem__(self, key):
        col, row, layer, direction = key
        if not (0 <= col < self.grid.cols and 0 <= row < self.grid.rows):
            raise KeyError(key)
        return self.counts[layer, direction][row if direction == "HORIZONTAL" else col]

    def __len__(self):
        return len(self.counts) * self.grid.rows * self.grid.cols

    def __iter__(self):
        for layer, direction in self.counts:
            for row in range(self.grid.rows):
                for col in range(self.grid.cols):
                    yield col, row, layer, direction


def fixed_rectangles(run, common):
    """Preserve all macro OBS and PIN geometry, with each geometry's layer.

    Decimal LEF coordinates are scaled exactly from their source tokens.
    Integer DBU results remain integers, avoiding float multiplication moving
    a track just outside a closed boundary. No obstruction is removed.
    """
    dbu = Fraction(str(run.def_definition.GetDatabaseUnits()))
    def exact(value, scale=1):
        if scale == 1 and isinstance(value,int):
            return value
        number=Fraction(str(value))*scale
        return number.numerator if number.denominator == 1 else number
    templates = {}
    for component in run.def_definition.getComponents():
        if component.macro_name not in templates:
            rectangles = []
            source=getattr(run,'_repair_lef_geometry',None)
            if source is not None:
                macro=source[component.macro_name]
                width,height=(exact(v,dbu) for v in macro['size'])
                rectangles=[(layer,tuple(exact(v,dbu) for v in box)) for layer,box in macro['rectangles']]
            else:  # Direct function callers and independent unit fixtures.
                macro = run.lef_definition.GetMacroByName(component.macro_name)
                width,height=exact(macro.size.width,dbu),exact(macro.size.height,dbu)
                ox,oy=exact(macro.origin.x,dbu),exact(macro.origin.y,dbu)
                boxes=[(o.layer_name,b) for o in macro.obstructions for b in o.bounds]
                boxes.extend((g.layer,b) for p in macro.pins.values() for port in p.ports for g in port.geometries for b in g.rect)
                rectangles=[(layer,(exact(b.xl,dbu)+ox,exact(b.yl,dbu)+oy,exact(b.xh,dbu)+ox,exact(b.yh,dbu)+oy)) for layer,b in boxes]
            templates[component.macro_name] = (width,height,rectangles)
        width,height,rectangles = templates[component.macro_name]
        dx,dy=exact(component.x),exact(component.y)
        transforms=(lambda x,y:(x,y),lambda x,y:(height-y,x),lambda x,y:(width-x,height-y),
                    lambda x,y:(y,width-x),lambda x,y:(width-x,y),lambda x,y:(y,x),
                    lambda x,y:(x,height-y),lambda x,y:(height-y,width-x))
        # DEF and common bindings expose distinct enum classes with the same
        # documented values. Their dictionary hashes are not interchangeable.
        orientation=int(getattr(component.orient,'value',component.orient))
        if not 0 <= orientation < 8:raise ValueError('Unsupported macro orientation')
        transform=transforms[orientation]
        for layer, box in rectangles:
            if layer not in run.layer_directions:
                continue  # CUT geometry does not consume a routing-layer track.
            p,q=transform(*box[:2]),transform(*box[2:])
            yield layer, (dx+min(p[0],q[0]),dy+min(p[1],q[1]),dx+max(p[0],q[0]),dy+max(p[1],q[1]))
    # IO PINs are fixed PIN geometry too, not only connectivity endpoints.
    for positions in getattr(run,'_repair_io_positions',{}).values():
        for box,layer,_ in positions:
            if layer in run.layer_directions:
                yield layer,(box.xl,box.yl,box.xh,box.yh)


def fixed_track_demand(run, common, capacity):
    used = {}
    grid = run.gcell_grid
    for layer, (xl, yl, xh, yh) in fixed_rectangles(run, common):
        cols = common.rectangle_cell_indices(xl, xh, grid.x_lines)
        rows = common.rectangle_cell_indices(yl, yh, grid.y_lines)
        horizontal = run.layer_directions[layer] == "HORIZONTAL"
        axis = "Y" if horizontal else "X"
        tracks = capacity.tracks.get(layer, {}).get(axis, ())
        if not tracks:
            continue
        lines = grid.y_lines if horizontal else grid.x_lines
        lower, upper = (yl, yh) if horizontal else (xl, xh)
        # A track exactly on an obstacle's upper edge is covered and belongs
        # to the next cell. Area-based cell lookup would miss that track.
        main = range(max(0, min(len(lines)-2, bisect_right(lines, lower)-1)),
                     min(len(lines)-1, bisect_right(lines, upper)))
        if lower > lines[-1] or upper < lines[0]:
            continue
        cross = cols if horizontal else rows
        for index in main:
            ids = track_indices(tracks, lower, upper, lines[index], lines[index+1],
                                final=index == len(lines)-2)
            if not ids:
                continue
            base = bisect_left(tracks, lines[index])
            mask = ((1 << len(ids))-1) << (ids.start-base)
            for other in cross:
                key = (other, index, layer) if horizontal else (index, other, layer)
                used[key] = used.get(key, 0) | mask
    return {key: bits.bit_count() for key, bits in used.items()}


def congestion(run, points, common, audit, *, fixed_counter=None):
    started = time.perf_counter()
    capacity = Capacity(run.def_data.tracks, run.gcell_grid)
    counter = fixed_track_demand if fixed_counter is None else fixed_counter
    demand = defaultdict(int, counter(run, common, capacity))
    fixed_total = sum(demand.values())
    fixed_by_layer = defaultdict(int)
    for (_, _, layer), value in demand.items():
        fixed_by_layer[layer] += value
    if any(value > capacity.get((*key, run.layer_directions[key[2]]), 0)
           for key, value in demand.items()):
        raise AssertionError("Fixed track union exceeds physical track capacity")
    route_total = 0
    guide_exempt = 0
    pin_cells = getattr(run,'_repair_pin_cells',{})
    grid = run.gcell_grid
    for name,rectangles in run.net_guides.items():
        used = set()
        for rect in rectangles:
            if rect.layer not in run.layer_directions:
                raise ValueError("Unvalidated routing layer")
            cols = common.rectangle_cell_indices(max(rect.xl, grid.die.x1),
                                                min(rect.xh, grid.die.x2), grid.x_lines)
            rows = common.rectangle_cell_indices(max(rect.yl, grid.die.y1),
                                                min(rect.yh, grid.die.y2), grid.y_lines)
            used.update((col, row, rect.layer) for col in cols for row in rows)
        exempt=pin_cells.get(name,set())
        guide_exempt += len(used & exempt)
        used.difference_update(exempt)
        route_total += len(used)
        for key in used:
            demand[key] += 1
    tsv_total = 0.0
    tsv_exempt = 0.0
    for point in points:
        for layer in (point.bottom_layer, point.top_layer):
            key=point.gcell_col,point.gcell_row,layer
            if key in pin_cells.get(point.net,()):
                tsv_exempt += run.tsv_congestion_ratio
                continue
            demand[key] += run.tsv_congestion_ratio
            tsv_total += run.tsv_congestion_ratio
    overflow, penalties = [], []
    zero_capacity = 0
    # Canonical accumulation order removes dependence on net declaration order.
    for key in sorted(demand):
        amount = demand[key]
        direction = run.layer_directions[key[2]]
        cap = capacity.get((*key, direction), 0)
        over = max(0, amount-cap)
        if over <= 0:
            continue
        if cap == 0:
            # Restores the explicit October bytecode constant at score.py:439.
            # A single 100**2 penalty per used zero-capacity cell, no fallthrough.
            ratio = 100.0
            zero_capacity += 1
        else:
            ratio = (over/cap)*0.1
        penalties.append(ratio*ratio)
        overflow.append(((*key, direction), amount, cap, over))
    total = math.fsum(row[3] for row in overflow)
    audit["congestion"] = {
        "gcell_width_dbu": run.gcell_width, "gcell_height_dbu": run.gcell_height,
        "fixed_track_demand": fixed_total, "guide_net_cell_demand": route_total,
        "fixed_track_demand_by_layer": dict(fixed_by_layer),
        "tsv_demand": tsv_total, "total_demand": math.fsum(demand.values()),
        "own_pin_guide_exempt_demand": guide_exempt,
        "own_pin_tsv_exempt_demand": tsv_exempt,
        "zero_capacity_demand_cells": zero_capacity,
        "penalty_sum": math.fsum(penalties), "all_occupied_cells_checked": len(demand),
        "implicit_empty_cells_have_zero_overflow": True,
        "capacity_entries_represented": len(capacity),
        "seconds": time.perf_counter()-started,
    }
    return (max((row[3] for row in overflow), default=0),
            total/len(demand) if demand else 0.0, total, overflow,
            dict(demand), math.fsum(penalties), len(overflow))


class GuideFormatError(ValueError):
    pass


def io_pin_positions(path, common):
    """Read every explicit rectangular IO PORT and its own DEF orientation.

    October's native binding exposes a NUL orientation here; its Python code
    reads one orientation per pin and then uses only the first PORT/layer.
    Unsupported polygon/via IO shapes fail explicitly, never disappear.
    """
    text = Path(path).read_text(encoding="utf-8")
    match = re.search(r"\bPINS\s+(\d+)\s*;(.*?)\bEND\s+PINS\b", text, re.S)
    if match is None:
        return {}
    records = re.findall(r"(?m)^\s*-\s+(\S+)(.*?);", match[2], re.S)
    if len(records) != int(match[1]):
        raise ValueError("PINS count disagrees with parsed records")
    orientation = dict(zip(("N","W","S","E","FN","FW","FS","FE"),
                           (common.PhysicalOrientation(i) for i in range(8))))
    result = {}
    number = r"([+-]?\d+)"
    for name, body in records:
        if name in result:
            raise ValueError("Duplicate IO pin name: "+name)
        blocks = re.split(r"\+\s*PORT\b", body)
        if len(blocks) > 1 and re.search(r"\+\s*(?:LAYER|POLYGON|VIA)\b", blocks[0]):
            raise ValueError("Mixed implicit and explicit IO PORT geometry: "+name)
        ports = blocks[1:] if len(blocks) > 1 else blocks
        positions = []
        for port in ports:
            if re.search(r"\+\s*(?:POLYGON|VIA)\b", port):
                raise ValueError("Unsupported nonrectangular IO pin: "+name)
            placements = re.findall(r"\+\s*(?:FIXED|PLACED|COVER)\s*\(\s*"+number+r"\s+"+number+r"\s*\)\s+(\w+)", port)
            if len(placements) != 1 or placements[0][2] not in orientation:
                raise ValueError("Missing or ambiguous IO PORT placement: "+name)
            x,y,o = placements[0]; x,y=int(x),int(y)
            rectangles = re.findall(r"\+\s*LAYER\s+(\S+)\s*\(\s*"+number+r"\s+"+number+r"\s*\)\s*\(\s*"+number+r"\s+"+number+r"\s*\)", port)
            if not rectangles or len(rectangles) != len(re.findall(r"\+\s*LAYER\b",port)):
                raise ValueError("Unsupported or missing IO rectangle: "+name)
            for layer,a,b,c,d in rectangles:
                a,b,c,d=map(int,(a,b,c,d))
                if a>c or b>d:
                    raise ValueError("Reversed IO rectangle: "+name)
                frame = common.Box(x,y,x,y)
                p = common.transform_orientation(common.Point(x+a,y+b),frame,orientation[o])
                q = common.transform_orientation(common.Point(x+c,y+d),frame,orientation[o])
                positions.append((common.Box(min(p.x,q.x),min(p.y,q.y),max(p.x,q.x),max(p.y,q.y)),
                                  layer,"PIN."+name))
        result[name] = positions
    return result


def parse_guide(path, common):
    """Consume every line of the documented net / ( / rectangles / ) grammar."""
    nets, current, state = {}, None, "net"
    with open(path, encoding="utf-8-sig", errors="strict") as stream:
        for line_number, raw in enumerate(stream, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            def fail(message):
                raise GuideFormatError(f"GUIDE line {line_number}: {message}")
            if state == "net":
                if len(line.split()) != 1 or line in ("(", ")"):
                    fail("expected one net name")
                if line in nets:
                    fail("duplicate net block: " + line)
                current, state = line, "open"
                nets[current] = []
            elif state == "open":
                if line != "(":
                    fail("expected opening parenthesis")
                state = "rect"
            elif line == ")":
                if not nets[current]:
                    fail("empty net block: " + current)
                state = "net"
            else:
                parts = line.split()
                if len(parts) != 5 or any(re.fullmatch(r"[+-]?\d+", x) is None for x in parts[:4]):
                    fail("expected four integer DBU coordinates and a layer")
                coords = tuple(map(int, parts[:4]))
                if coords[0] > coords[2] or coords[1] > coords[3]:
                    fail("rectangle bounds are reversed")
                # Retain October's support for degenerate rectangles; changing
                # their admission requires a separately chosen geometry rule.
                if not re.fullmatch(r"metal(?:[1-9]|1[0-9]|20)", parts[4]):
                    fail("expected metal1 through metal20")
                nets[current].append(common.GuideRect(*coords, parts[4]))
    if state != "net":
        raise GuideFormatError("GUIDE ended inside an unfinished net block")
    if not nets:
        raise GuideFormatError("GUIDE has no nets")
    return nets


def connected(rectangles, common, directions=None, *, tsv_point=None):
    """Full connectivity; directions selects the announcement predicate.

    The x sweep removes only pairs provably outside the predicate tolerance.
    Every remaining potential pair is tested. A graph admits a spanning tree
    iff this disjoint-set check has one component.
    """
    count = len(rectangles)
    if not count:
        return False
    parents = list(range(count))
    def find(i):
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i
    active = defaultdict(list)
    tolerance = 1e-6 if directions is None else 0
    for i in sorted(range(count), key=lambda k: (rectangles[k].xl, k)):
        rect = rectangles[i]
        layer = common.parse_layer_num(rect.layer)
        for other_layer in (layer-1, layer, layer+1):
            remaining = []
            for j in active[other_layer]:
                other = rectangles[j]
                if other.xh < rect.xl-tolerance:
                    continue
                remaining.append(j)
                if other.yh < rect.yl-tolerance or rect.yh < other.yl-tolerance:
                    continue
                if tsv_point is not None and {layer, other_layer} == {10, 11}:
                    x, y = tsv_point
                    if not (max(rect.xl, other.xl) < x < min(rect.xh, other.xh) and
                            max(rect.yl, other.yl) < y < min(rect.yh, other.yh)):
                        continue
                if (common._rectangles_connect(rect, other) if directions is None else
                    directional_connection(rect,other,directions,common)):
                    a, b = find(i), find(j)
                    if a != b:
                        parents[a] = b
            active[other_layer] = remaining
        active[layer].append(i)
    return len({find(i) for i in range(count)}) == 1


def directional_connection(a,b,directions,common):
    la,lb=common.parse_layer_num(a.layer),common.parse_layer_num(b.layer)
    if not (1<=la<=20 and 1<=lb<=20) or abs(la-lb)>1:return False
    ox=min(a.xh,b.xh)-max(a.xl,b.xl)
    oy=min(a.yh,b.yh)-max(a.yl,b.yl)
    if la!=lb:return ox>0 and oy>0
    direction=directions[a.layer]
    if direction=='HORIZONTAL':return ox>=0 and oy>0
    if direction=='VERTICAL':return oy>=0 and ox>0
    raise ValueError('Unsupported routing-layer direction')


def overlap_components(lower, upper):
    """Components of the regularized positive-area intersection of two unions.

    Coordinates remain exact integer DBU. Positive-area overlap is closed:
    its regions meeting at an edge or corner are one component. Zero-width
    input rectangles and boundary-only cross-layer overlap contribute no area
    and cannot bridge regions. A sweep processes EVERY coordinate event and
    every active y interval; this is exact geometry, not a sampled grid.
    """
    if not lower or not upper:
        return 0
    if len(lower) == len(upper) == 1:
        a, b = lower[0], upper[0]
        return int(max(a.xl,b.xl) < min(a.xh,b.xh) and max(a.yl,b.yl) < min(a.yh,b.yh))
    events = defaultdict(list)
    for side, rectangles in enumerate((lower, upper)):
        for rect in rectangles:
            if rect.xl < rect.xh and rect.yl < rect.yh:
                events[rect.xl].append((side, (rect.yl, rect.yh), 1))
                events[rect.xh].append((side, (rect.yl, rect.yh), -1))
    coordinates = sorted(events)
    active = [Counter(), Counter()]
    unions = [[], []]
    parents, previous = [], []
    components = 0

    def find(i):
        while parents[i] != i:
            parents[i] = parents[parents[i]]
            i = parents[i]
        return i

    for x in coordinates[:-1]:
        changed = set()
        for side, interval, delta in events[x]:
            active[side][interval] += delta
            if active[side][interval] == 0:
                del active[side][interval]
            changed.add(side)
        for side in changed:
            merged = []
            for lo, hi in sorted(active[side]):
                if merged and lo <= merged[-1][1]:
                    merged[-1] = (merged[-1][0], max(hi, merged[-1][1]))
                else:
                    merged.append((lo, hi))
            unions[side] = merged
        left, right = unions
        i = j = 0
        intersections = []
        while i < len(left) and j < len(right):
            lo, hi = max(left[i][0], right[j][0]), min(left[i][1], right[j][1])
            if lo < hi:
                if intersections and lo <= intersections[-1][1]:
                    intersections[-1] = (intersections[-1][0], max(hi, intersections[-1][1]))
                else:
                    intersections.append((lo, hi))
            if left[i][1] < right[j][1]:
                i += 1
            else:
                j += 1
        current = []
        j = 0
        for lo, hi in intersections:
            identity = len(parents)
            parents.append(identity)
            components += 1
            while j < len(previous) and previous[j][1] < lo:
                j += 1
            k = j
            while k < len(previous) and previous[k][0] <= hi:
                a, b = find(identity), find(previous[k][2])
                if a != b:
                    parents[a] = b
                    components -= 1
                k += 1
            current.append((lo, hi, identity))
        previous = current
    return components


def ordinary_via_regions(rectangles, common):
    by_layer = defaultdict(list)
    for rect in rectangles:
        by_layer[common.parse_layer_num(rect.layer)].append(rect)
    # metal10/metal11 is the separate TSV boundary, never an ordinary via.
    return sum(overlap_components(by_layer[layer], by_layer[layer+1])
               for layer in sorted(by_layer)
               if layer not in (10, 20) and layer+1 in by_layer)


def check_connections(run, common, checker, audit):
    started = time.perf_counter()
    def_nets = run.def_definition.getNets()
    names = {net.name for net in def_nets}
    if len(names) != len(def_nets):
        raise ValueError("Duplicate DEF net names")
    extra = set(run.net_guides)-names
    missing = names-set(run.net_guides)
    def illegal(message, rule):
        raise checker.EvaluationError(message, category=checker.LEGALITY,
                                      rule=rule, hint="Correct the reported input geometry.")
    if extra:
        illegal("GUIDE contains unknown net: "+sorted(extra)[0], checker.RULE_FORMAT)
    if missing:
        illegal("GUIDE missing net: "+sorted(missing)[0], checker.RULE_NET_CONNECTED)
    checked_pins = 0
    for net in def_nets:
        rects = run.net_guides[net.name]
        if not rects:
            illegal("Empty GUIDE net: "+net.name, checker.RULE_NET_CONNECTED)
        by_layer = defaultdict(list)
        for rect in rects:
            by_layer[rect.layer].append(rect)
        dies, crossing = set(), []
        for pin, positions in run.net_to_pins[net.name].items():
            selected = None
            for position in positions:
                if checker._guide_contian_pin(by_layer[position[1]], [position]) >= 0:
                    selected = position
                    break
            if selected is None:
                illegal(f"Uncovered pin: {net.name}/{pin}", checker.RULE_NET_CONNECTED)
            checked_pins += 1
            dies.add(common.die_of_layer(selected[1]))
            if selected[1] in (common.TSV_LOWER_LAYER, common.TSV_UPPER_LAYER):
                crossing.append(selected)
        if len(dies) > 1:
            run.nets_crossing_dies[net.name] = crossing
        if not connected(rects, common, run.layer_directions):
            illegal("Disconnected GUIDE net: "+net.name, checker.RULE_NET_CONNECTED)
    audit["connectivity"] = {"all_nets_checked": len(def_nets), "all_pins_checked": checked_pins,
                             "seconds": time.perf_counter()-started,
                             "predicate": "announcement direction-specific exact rectangle predicate"}


def reference_length(run, hpwl):
    """Same FLUTE calls and arithmetic; reuse bounded scratch arrays per run."""
    flute = hpwl.flute_pybind.SteinerFlute()
    maximum = flute.GetMaxDegree()
    xs, ys = [0]*maximum, [0]*maximum
    planar, vias, crossing = 0.0, 0, 0
    for name in run.net_guides:
        pins = run.net_to_pins[name]
        if not 1 <= len(pins) <= maximum:
            raise ValueError(f"FLUTE degree unsupported for {name}: {len(pins)}; no net was skipped")
        for i, positions in enumerate(pins.values()):
            x, y = positions[0][0].center()
            xs[i], ys[i] = int(x), int(y)
        length, count = flute.GetSteinerLength(len(pins), xs, ys, False)
        if run.net_to_die[name] == "crossing":
            count += 10
            crossing += 1
        planar += length
        vias += count
    step = max(run.gcell_width, run.gcell_height)
    return planar + (vias*run.via_ratio*step + crossing*run.tsv_ratio*step)


def install(modules, audit, source_lef_geometry=None, mode='announcement'):
    common, checker, hpwl, wire_length, score = modules
    common.load_history_data = False
    # These optional caches are not evaluation outputs and are never consumed
    # in this mode. All pins are freshly computed and checked on every run.
    common.save_net_to_pins = lambda *args, **kwargs: None
    common.save_net_to_die = lambda *args, **kwargs: None
    old_position = common.get_position
    old_parse_pins = score.parse_def_pins
    def parse_pins(path, run):
        old_parse_pins(path, run)
        run._repair_lef_geometry=source_lef_geometry
        try:
            run._repair_io_positions = io_pin_positions(path, common)
        except ValueError as error:
            raise checker.EvaluationError(str(error), category=common.INPUT,
                                          rule="All IO PORT geometry must be understood",
                                          hint="Supply supported rectangular placed IO PORTs.") from error
    def get_position(connection, run):
        if connection.instance == "PIN":
            return run._repair_io_positions.get(connection.pin, [])
        return old_position(connection, run)
    score.parse_def_pins = parse_pins
    common.get_position = get_position
    original_parser = common.parse_guide
    def checked_parser(path):
        try:
            return parse_guide(path, common)
        except (GuideFormatError, UnicodeError) as error:
            raise checker.EvaluationError(str(error), category=checker.LEGALITY,
                                          rule=checker.RULE_FORMAT, hint="Use the documented GUIDE grammar.") from error
    common.parse_guide = checked_parser
    checker.check_net_connection = lambda run: check_connections(run, common, checker, audit)
    score.compute_congestion = lambda run, points: congestion(run, points, common, audit)
    score.build_capacity = Capacity
    old_net_wire = wire_length.get_net_wire_length
    def region_net_wire(name, run):
        legacy_cost, tsv_count, legacy_vias = old_net_wire(name, run)
        started = time.perf_counter()
        regions = ordinary_via_regions(run.net_guides[name], common)
        unit = run.via_ratio * max(run.gcell_width, run.gcell_height)
        details = audit.setdefault("via_rule", {"id": "overlap-components-v1",
            "legacy_rectangle_count": 0, "overlap_region_count": 0,
            "wire_cost_delta_dbu": 0.0, "all_nets_checked": 0,
            "physical_via_count": False, "seconds": 0.0})
        details["legacy_rectangle_count"] += legacy_vias
        details["overlap_region_count"] += regions
        details["wire_cost_delta_dbu"] += (regions-legacy_vias)*unit
        details["all_nets_checked"] += 1
        details["seconds"] += time.perf_counter()-started
        return math.fsum((legacy_cost, -legacy_vias*unit, regions*unit)), tsv_count, regions
    if mode=='fair':wire_length.get_net_wire_length = region_net_wire
    old_wire = score.compute_wire_length
    def checked_wire(run):
        started = time.perf_counter()
        result = old_wire(run)
        audit["wirelength"] = {"all_nets_scored": len(run.net_guides),
                               "total_cost_dbu": result[1], "reference_cost_dbu": result[2],
                               "rectangle_tsv_cost_count": result[3], "ordinary_via_proxy_count": result[4],
                               "seconds": time.perf_counter()-started}
        return result
    score.compute_wire_length = checked_wire
    def checked_reference(run):
        try:
            return reference_length(run, hpwl)
        except ValueError as error:
            raise checker.EvaluationError(str(error), category=common.INPUT,
                                          rule="Every input net must have a complete reference cost",
                                          hint="The pinned FLUTE backend cannot score this net degree.") from error
    hpwl.compute_hpwl = checked_reference
    return original_parser
