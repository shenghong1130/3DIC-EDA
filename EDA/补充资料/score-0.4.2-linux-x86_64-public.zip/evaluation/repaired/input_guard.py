"""Fail explicitly for geometry the pinned native representation cannot expose.

This is a supported-geometry gate, not a second complete DEF/LEF parser. The
native parsers still parse the supported files; legality is never inferred
from this gate alone. Unsupported inputs are unscorable, not a valid zero score.
"""
import math
from fractions import Fraction
from pathlib import Path
import re


def decimal_token(value):
    """Render a finite decimal Fraction exactly, without a float round trip."""
    denominator = value.denominator
    powers = []
    for factor in (2, 5):
        count = 0
        while denominator % factor == 0:
            denominator //= factor
            count += 1
        powers.append(count)
    if denominator != 1:
        raise ValueError('Coordinate is not a finite decimal')
    places = max(powers)
    scaled = value.numerator * 2**(places-powers[0]) * 5**(places-powers[1])
    if not places:
        return str(scaled)
    digits = str(abs(scaled)).zfill(places+1)
    return ('-' if scaled < 0 else '') + digits[:-places] + '.' + digits[-places:]


def validate_lef_geometry(paths, collect=False, normalized_lefs=None):
    counts = {"macros": 0, "rectangles": 0}
    source_macros = {}
    number = r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?"
    for path in paths:
        original = Path(path).read_text(encoding="utf-8-sig")
        # Quoted properties and comments are data, not shape declarations.
        # Keep offsets/newlines so a private canonical copy preserves all
        # non-coordinate source content, including properties and comments.
        text = re.sub(r'"(?:[^"\\]|\\.)*"|#[^\n]*',
                      lambda m: ''.join('\n' if c == '\n' else ' ' for c in m[0]), original)
        replacements = []
        changed_rectangles = changed_origins = 0
        macros = list(re.finditer(r"(?m)^[ \t]*MACRO[ \t]+(\S+)[ \t]*\n(.*?)^[ \t]*END[ \t]+\1[ \t]*(?=\n|$)", text, re.S))
        if len(macros) != len(re.findall(r"(?m)^[ \t]*MACRO\b", text)):
            raise ValueError("Unsupported or unfinished LEF MACRO declaration")
        for macro in macros:
            name, body = macro[1], macro[2]
            if name in source_macros:
                raise ValueError("Duplicate LEF MACRO definition: "+name)
            counts["macros"] += 1
            if re.search(r"(?:^|[;\n])\s*(?:POLYGON|PATH|VIA)\b|\bRECT\s+ITERATE\b", body):
                raise ValueError("Unsupported LEF PIN/OBS geometry in macro "+name+": only plain RECT is supported")
            origins = list(re.finditer(r"\bORIGIN\s+([^;]+);", body))
            if len(origins) > 1:
                raise ValueError('Duplicate LEF ORIGIN in macro '+name)
            origin = origins[0] if origins else None
            tokens = origin[1].split() if origin else ('0', '0')
            if len(tokens) != 2 or any(re.fullmatch(number,v) is None or not math.isfinite(float(v)) for v in tokens):
                raise ValueError('Unsupported LEF ORIGIN in macro '+name)
            ox, oy = map(Fraction, tokens)
            if ox or oy:
                # LEF shifts local geometry by ORIGIN before orientation and
                # DEF placement. Give the native parser an equivalent zero-
                # origin private copy so PIN access, reference points, OBS and
                # resource credits all see the same exact translated geometry.
                replacements.append((macro.start(2)+origin.start(1),
                                     macro.start(2)+origin.end(1), '0 0 '))
                changed_origins += 1
                counts['nonzero_origins'] = counts.get('nonzero_origins', 0)+1
            rectangles = list(re.finditer(r"\bRECT\s+([^;]*);", body))
            if len(rectangles) != len(re.findall(r"\bRECT\b", body)):
                raise ValueError("Unfinished LEF RECT in macro "+name)
            canonical = {}
            for rectangle in rectangles:
                geometry = rectangle[1]
                values = geometry.split()
                if len(values) != 4 or any(re.fullmatch(number,v) is None or not math.isfinite(float(v)) for v in values):
                    raise ValueError("Unsupported LEF RECT syntax in macro "+name)
                # LEF RECT specifies opposite corners, not ordered bounds.
                # Compare exact decimals and move the original tokens; do not
                # round coordinates, expand zero-area shapes, or rewrite GUIDE.
                exact = tuple(map(Fraction, values))
                ordered = list(values)
                if exact[0] > exact[2]:ordered[0],ordered[2] = ordered[2],ordered[0]
                if exact[1] > exact[3]:ordered[1],ordered[3] = ordered[3],ordered[1]
                if ox or oy:
                    ordered = [decimal_token(Fraction(v)+offset)
                               for v,offset in zip(ordered,(ox,oy,ox,oy))]
                canonical[geometry] = tuple(ordered)
                if ordered != values:
                    changed_rectangles += 1
                    replacements.append((macro.start(2)+rectangle.start(1),
                                         macro.start(2)+rectangle.end(1), ' '.join(ordered)+' '))
                counts["rectangles"] += 1
            size=re.search(r"\bSIZE\s+("+number+r")\s+BY\s+("+number+r")\s*;",body)
            if size is None:
                raise ValueError("Missing or unsupported LEF SIZE in macro "+name)
            source_rectangles=[]
            layer=None
            for token in re.finditer(r"\bLAYER\s+(\S+)\s*[^;]*;|\bRECT\s+([^;]*);",body):
                if token[1] is not None:
                    layer=token[1]
                else:
                    if layer is None:raise ValueError("LEF RECT without a layer in macro "+name)
                    source_rectangles.append((layer,canonical[token[2]]))
            # Keep logical PIN ownership independently of the fixed union.
            # All supported PORTs/layers belong to the same logical PIN.
            pins={}
            blocks=list(re.finditer(r"(?m)^[ \t]*PIN[ \t]+(\S+)[ \t]*\n(.*?)^[ \t]*END[ \t]+\1[ \t]*(?=\n|$)",body,re.S))
            if len(blocks)!=len(re.findall(r"(?m)^[ \t]*PIN\b",body)):
                raise ValueError("Unsupported or unfinished LEF PIN declaration in macro "+name)
            for pin in blocks:
                if pin[1] in pins:raise ValueError("Duplicate LEF PIN in macro "+name)
                layer=None;geometries=[]
                for token in re.finditer(r"\bLAYER\s+(\S+)\s*[^;]*;|\bRECT\s+([^;]*);",pin[2]):
                    if token[1] is not None:layer=token[1]
                    else:
                        if layer is None:raise ValueError("PIN RECT without a layer")
                        geometries.append((layer,canonical[token[2]]))
                pins[pin[1]]=geometries
            source_macros[name]={'size':size.groups(),'rectangles':source_rectangles,'pins':pins}
        if normalized_lefs is not None and replacements:
            normalized = original
            for start,end,value in sorted(replacements, reverse=True):
                normalized = normalized[:start]+value+normalized[end:]
            normalized_lefs[Path(path)] = {'text':normalized, 'rectangles_normalized':changed_rectangles,
                                          'origins_normalized':changed_origins}
    return (counts,source_macros) if collect else counts
