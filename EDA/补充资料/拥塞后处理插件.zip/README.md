# 独立 GUIDE 拥塞后处理插件

版本 0.1.1。输入任意布线程序生成的 GUIDE 及同一设计的原始 DEF/LEF，输出新的 GUIDE。
插件自行读取原引脚、矩形障碍、网格和轨道，重建资源需求，再进行局部三维绕行。
不需要原布线程序、其候选池、项目缓存、原生解析动态库或本地评估器。

插件改变实际 GUIDE 几何，不修改 DEF/LEF。其目标是降低拥塞，同时保留原引脚
连接和跨 die 接口。有限候选不保证任意输入改善，也不保证全局最优或物理签核。

## 安装与自检

使用 Python 3.10，已验证版本为 3.10.18；交付验证平台为 Linux x86_64 CPU。
先在自己的 Python 环境中安装包内列明的依赖，再运行人工样例：

```bash
python3 -m pip install -r requirements.txt
JAX_PLATFORMS=cpu python3 -B selfcheck.py
```

依赖固定为 JAX/JAXlib、NumPy、SciPy、ml_dtypes 和 opt_einsum 的已验证版本。
包体不包含 Python 运行时或依赖 wheel；离线使用时需提前准备这些依赖。
插件运行不联网，不自动安装软件，不导入布线器。请将三个插件 `.py` 文件放在一起。

## 命令行使用

先运行人工设计，输出必须是新文件，父目录必须已存在：

```bash
JAX_PLATFORMS=cpu python3 -B congestion_postprocess.py \
  --guide examples/synthetic.guide \
  --def examples/synthetic.input.def \
  --lef examples/synthetic.lef \
  --window 2 --rounds 2 --wire-budget-dbu 300 \
  --output synthetic.processed.guide
```

该人工设计的主模型总溢出由 1 降到 0，计费成本增加 160 DBU。它使用一个小型
人工网和一个未接入该网的固定 PIN 来制造资源热点，不能代表真实设计的收益。

处理自己的已有结果：

```bash
JAX_PLATFORMS=cpu python3 -B congestion_postprocess.py \
  --guide input.guide --def input.def --lef technology.lef cells.lef \
  --window 4 --rounds 2 --wire-budget-dbu 0 \
  --output processed.guide > summary.json
```

默认线长预算为 0：只有累计计费成本不增加的修改才能被接受。若需要允许更长的
实际绕行，显式提高 `--wire-budget-dbu`，单位是整数 DBU。它限制本模型成本的
累计增量，不是微米长度，也不能直接当作线长分变化。原结果始终保留；没有改善
时也会生成一份几何不变的新 GUIDE。失败不会发布部分文件，不覆盖已有输出。

标准输出是 JSON 聚合摘要，包含各资源模型前后的总溢出、拥塞分、改动网数、
成本增量和检查范围，不包含路径、网名、输入散列或机器身份。退出码 0 表示
新文件已完成内置检查并写出，2 表示参数、输入或处理失败。退出码不是外部
评估器的合法性结论。

| 参数 | 含义 |
|---|---|
| `--guide` | 原始 GUIDE，只读；完整网集合、正面积整数 DBU 矩形 |
| `--def` | 同一设计的原始 DEF，只读 |
| `--lef` | 一份或多份原始 LEF，只读 |
| `--output` | 新 GUIDE，必须是不存在的路径 |
| `--window` | 三维窗口半径，默认 2，范围 0–32；0 仅尝试删除与邻层提案 |
| `--rounds` | 最多迭代次数，默认 2，范围 1–16；一轮无接受项则提前结束 |
| `--wire-budget-dbu` | 累计计费成本可增加的整数 DBU，默认 0 |
| `--profile` | 主资源口径，默认 `actual`，见下文 |
| `--version` | 显示插件版本 |

扩大窗口和增加轮数会增加运行开销。默认 CPU 即可；插件使用 JAX 的 64 位
增量计算，API 调用也会启用该设置。

## 资源口径与验收

默认 `actual` 同时计算两套实际层固定占用：半开轨道边界 `[lower,upper)`
作为主模型，闭上边界作为对照。HORIZONTAL 使用 Y 方向轨道坐标，VERTICAL
使用 X 方向轨道坐标；重复轨道先去重，固定矩形按轨道身份求并集。每个网在
每个占用层格计一次 GUIDE 需求，仅按该网自己的原 PIN 几何抵扣。选中 TSV
在接口两层各增加一个需求单位，仍按所属网抵扣。

拥塞分为 `100 / sqrt(1 + sum((0.1 * overflow / capacity)^2))`。有需求溢出的
零容量层格单独增加 10000 惩罚。总溢出和平方惩罚同时用于验收，不能只比较
总溢出推断分数一定提高。

可选 `first-layer-projected` 或 `first-layer-original` 是显式的兼容假说：
同一 PIN 的固定矩形计入其首层；前者把全部 PIN 矩形投到首层后抵扣，后者
只用原本就在首层的矩形抵扣。两者都保留原 PIN 连接和原障碍几何，并同时
检查另一兼容假说及两套实际层模型。它们不把首层归属解释为真实物理占用，
也不声称已恢复任何未公开评估器的完整实现。IO 固定矩形保留原层。

每个候选必须使主模型总溢出和平方惩罚严格下降，其他模型两项都不增加，并满足：

- 每个原始 PIN 仍有正面积接触；同层沿首选方向连接，相邻层需正面积交叠。
- M10/M11 矩形及顺序保持不变，选中的 TSV 点也保持不变；die 内网不能跑到另一 die。
- 不新增与原 OBS 相交的层格；对已占用格内部的矩形扩张，额外检查新 OBS 交叠。
- 累计模型成本增量不超过预算。结束时独立重建所有修改的资源增量并逐元素比较。

代价模型按方向累计占用格长度，并使用显式的按格预筛选、矩形重叠普通 via
计数；普通 via/TSV 单价分别为最大名义格长的 3/6 倍。它是预算用的 GUIDE
代理成本，不是详细物理线长、真实 via 数或任意评估器的通用等价模型。

TSV 模型从去重/包含清理后的 M10/M11 正面积交叠区域选择点。支持一个区域，
或结合原接口 PIN 选择的两个区域；歧义和超出支持范围会报错。接口保持不变
使同一热评估输入下的选中 TSV 点不变，但插件不运行热仿真，也不承诺运行
效率分或全部其他评分项不变。输出应再由实际目标评估器完整重评。

## Python API

把解压目录加入调用程序的模块搜索路径，可直接导入：

```python
from congestion_postprocess import process

summary = process(
    "input.guide", "processed.guide", "input.def",
    ["technology.lef", "cells.lef"],
    profile="actual", window=4, rounds=2, wire_budget_dbu=0,
)
```

需要接入自有资源适配器时，`congestion_core.py` 提供底层 `ResourceView` 和
`patch`。每套视图的 `demand/capacity` 为整数 `[layer,row,col]` 数组，需求必须
已经包含固定、GUIDE 和选中 TSV 需求；`exemptions[net]` 是该模型的自有 PIN
抵扣层格集合，平坦索引为 `(layer * rows + row) * cols + col`。
调用方还必须提供原引脚/连通检查、费用回调和新增障碍掩码；底层接口本身不会
猜测这些规则。普通使用者应优先使用上述完整 `process` 接口。

## 支持范围与限制

支持二十个连续命名的 `metal1` 至 `metal20` routing layer，前缀大小写一致并
原样输出，第 10/11 层为固定跨 die 接口。每轴支持一条从矩形 DIEAREA 下界
开始并覆盖上界的规则 GCELLGRID，允许末端短格。名义格长至少 4 DBU，整个
网格不超过 30000000 个层格，每个层格最多 63 条物理轨道。

支持零 ORIGIN 宏、非迭代 RECT PIN/OBS、八种 DEF 朝向、简单 PLACED/FIXED
组件及带独立放置的矩形 IO PORT。LEF 十进制坐标使用精确比例转换；原层名、
网归属和全部引脚接入矩形保留。非零宏原点、POLYGON/PATH/ITERATE、几何 MASK
和 VIA 放置、非空 DEF BLOCKAGES/SPECIALNETS、预布线 DEF、多段网格、带额外
属性的组件放置等超出当前解析范围，会明确失败，不能静默忽略。

GUIDE 必须覆盖 DEF 的完整网集合，没有重复网名、完全重复矩形、空网、零面积、
越界或非优选方向超出一格宽的矩形；输入的原 PIN 接触和方向连通也必须通过。
插件保留既有 OBS 交叠问题而不扩大它们，不修复所有原设计问题。逐轨分配、
其他 PIN 避让、金属宽度/间距、CUT 包围、普通 via 和 TSV 实体、时序与工艺
规则不在此全局布线模型的签核范围。

## 包内容与隐私

本包仅含三个插件模块、使用说明、依赖版本、人工例子、自检和
[完整性清单](SHA256.json)。不包含真实设计、真实成绩、截图、开发日志、内部
配置、仓库历史、身份信息、绝对环境路径或凭据。`selfcheck.py` 只验证人工输入
和包完整性，不是官方评分器。

运行时输出 GUIDE 必须保留调用者提供的网名和几何，属于调用者自己的设计
数据；它不会因使用本插件而自动成为脱敏文件。插件没有上传或遥测功能。
